package com.azhon.mvvm.lazy;

import java.util.List;

/**
 * 项目名:    TODO-MVVM
 * 包名       com.azhon.mvvm.lazy
 * 文件名:    JueJinBean
 * 创建时间:  2019-03-29 on 10:38
 * 描述:     TODO
 *
 * @author 阿钟
 */

public class JueJinBean {

    /**
     * s : 1
     * m : ok
     * d : {"total":10,"entrylist":[{"collectionCount":5,"isEvent":false,"commentsCount":0,"gfw":false,"buildTime":1.5538270211392E9,"checkStatus":true,"objectId":"5c9d78a96fb9a070d0141255","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553826996,"ngxCached":true,"title":"后端","id":"5597a063e4b08a686ce57030"},{"ngxCachedTime":1553826980,"ngxCached":true,"title":"Java","id":"559a7207e4b08a686d25703e"}],"updatedAt":"2019-03-29T02:37:01.137Z","rankIndex":94.268749986838,"hot":false,"autoPass":true,"originalUrl":"https://juejin.im/post/5c9d78715188251e3e3c8a7f","verifyCreatedAt":"2019-03-29T01:45:13.966Z","createdAt":"2019-03-29T01:45:13.966Z","user":{"community":{"github":{"username":"dyc87112","avatarLarge":"https://avatars0.githubusercontent.com/u/3391170?v=4","uid":"3391170"}},"collectedEntriesCount":23,"company":"关注我，每日技术干货推送，每月福利免费领取！","followersCount":2786,"followeesCount":6,"role":"editor","postedPostsCount":41,"isAuthor":false,"postedEntriesCount":40,"totalCommentsCount":47,"ngxCachedTime":1553827021,"ngxCached":true,"viewedEntriesCount":120,"jobTitle":"","subscribedTagsCount":29,"totalCollectionsCount":781,"username":"程序猿DD_","avatarLarge":"https://user-gold-cdn.xitu.io/2019/3/21/1699f0e5d13e9789?w=568&h=568&f=jpeg&s=33909","objectId":"58e10d35570c350057a277bc"},"author":"","screenshot":"","original":true,"hotIndex":422.0601,"content":"最近对《Spring Cloud Alibaba基础教程》系列的催更比较多，说一下最近的近况：因为打算Spring Boot 2.x一起更新。所以一直在改博客Spring Boot专题页和Git仓库的组织。由于前端技术太过蹩脚，花了不少时间。大家不用担心，这个系列不会太监，因为\u2026","title":"说说我为什么看好Spring Cloud Alibaba","lastCommentTime":"1970-01-01T00:00:00.Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":370,"summaryInfo":"最近对《Spring Cloud Alibaba基础教程》系列的催更比较多，说一下最近的近况：因为打算Spring Boot 2.x一起更新。所以一直在改博客Spring Boot专题页和Git仓库的组织。由于前端技术太过蹩脚，花了不少时间。大家不用担心，这个系列不会太监，因为我真心看好这个套件的...","isCollected":false},{"collectionCount":11,"isEvent":false,"commentsCount":0,"gfw":false,"buildTime":1.5538270171562E9,"checkStatus":true,"objectId":"5c9d57435188252d5c745326","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553827000,"ngxCached":true,"title":"Go","id":"555e9a80e4b00c57d9955de2"}],"updatedAt":"2019-03-29T02:36:57.155Z","rankIndex":28.460316899721,"hot":false,"autoPass":true,"originalUrl":"https://juejin.im/post/5c9d5631f265da60d82dde9c","verifyCreatedAt":"2019-03-28T23:22:43.559Z","createdAt":"2019-03-28T23:22:43.559Z","user":{"community":null,"collectedEntriesCount":88,"company":"公众号：Golang来啦","followersCount":191,"followeesCount":20,"role":"editor","postedPostsCount":19,"isAuthor":false,"postedEntriesCount":7,"totalCommentsCount":14,"ngxCachedTime":1553826950,"ngxCached":true,"viewedEntriesCount":1289,"jobTitle":"","subscribedTagsCount":67,"totalCollectionsCount":334,"username":"Seekload","avatarLarge":"https://user-gold-cdn.xitu.io/2018/11/20/1673082d8c30d80d?w=225&h=225&f=png&s=4504","objectId":"573730741532bc006548416a"},"author":"","screenshot":"https://user-gold-cdn.xitu.io/2019/3/29/169c69c932711a62?w=1000&h=666&f=jpeg&s=65444","original":true,"hotIndex":460.0793,"content":"在一些面向对象的编程语言中，例如 Java、PHP 等，接口定义了对象的行为，只指定了对象应该做什么。行为的具体实现取决于对象。 在 Go 语言中，接口是一组方法的集合，但不包含方法的实现、是抽象的，接口中也不能包含变量。当一个类型 T 提供了接口中所有方法的定义时，就说 T \u2026","title":"Go 语言接口详解（一）","lastCommentTime":"1970-01-01T00:00:00.Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":348,"summaryInfo":"在一些面向对象的编程语言中，例如 Java、PHP 等，接口定义了对象的行为，只指定了对象应该做什么。行为的具体实现取决于对象。 在 Go 语言中，接口是一组方法的集合，但不包含方法的实现、是抽象的，接口中也不能包含变量。当一个类型 T 提供了接口中所有方法的定义时，就说 T 实现了接口。接口指定...","isCollected":false},{"collectionCount":3,"isEvent":false,"commentsCount":0,"gfw":false,"buildTime":1.5538270351365E9,"checkStatus":true,"objectId":"5c9cdde46fb9a070fc62516f","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553826952,"ngxCached":true,"title":"Spring","id":"5847c9a5ac502e006ce63fa1"}],"updatedAt":"2019-03-29T02:37:15.135Z","rankIndex":1.2119021773034,"hot":false,"autoPass":false,"originalUrl":"https://juejin.im/post/5c9cdcf06fb9a070cb24c4d1","verifyCreatedAt":"2019-03-28T14:58:10.827Z","createdAt":"2019-03-28T14:58:10.827Z","user":{"community":{"weibo":{"selfDescription":"实施搬过砖，银行打过杂，倒闭卖公司，投机又倒把。","uid":"1144349627","blogAddress":"http://weibo.com/akirapanda","username":"废柴大叔阿基拉","avatarLarge":"http://tva4.sinaimg.cn/crop.0.0.180.180.180/443563bbjw1e8qgp5bmzyj2050050aa8.jpg"}},"collectedEntriesCount":2,"company":"","followersCount":28,"followeesCount":32,"role":"guest","postedPostsCount":5,"isAuthor":false,"postedEntriesCount":0,"totalCommentsCount":5,"ngxCachedTime":1553827042,"ngxCached":true,"viewedEntriesCount":62,"jobTitle":"咨询工程师","subscribedTagsCount":2,"totalCollectionsCount":23,"username":"废柴大叔阿基拉","avatarLarge":"https://user-gold-cdn.xitu.io/2019/3/25/169b46cc8fe5df08?w=454&h=454&f=jpeg&s=19650","objectId":"5c98aef96fb9a071105de2f6"},"author":"","screenshot":"","original":true,"hotIndex":125.0634,"content":"我们在某一期其实已经对Authentication身份验证中的主要组件进行过介绍，并且通过几期的分享让大家大致了解了Web应用大致利用核心进行身份验证的流程和相关的扩展点。 这一期我们用一期的篇章把关注点放在Authentication身份验证核心最主要的几个服务Authent\u2026","title":"Spring Security小教程 Vol 5.核心组件AuthenticationManager专题","lastCommentTime":"1970-01-01T00:00:00.Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":93,"summaryInfo":"我们在某一期其实已经对身份验证中的主要组件进行过介绍，并且通过几期的分享让大家大致了解了Web应用大致利用核心进行身份验证的流程和相关的扩展点。这一期我们用一期的篇章把关注点放在身份验证核心最主要的几个服务、和，三个顶层接口进行展开。通过Spring Security对这些接口服务的实现进行说明讲...","isCollected":false},{"collectionCount":17,"isEvent":false,"commentsCount":0,"gfw":false,"buildTime":1.553826871352E9,"checkStatus":true,"objectId":"5c9cd4546fb9a071071947bf","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553826980,"ngxCached":true,"title":"Java","id":"559a7207e4b08a686d25703e"}],"updatedAt":"2019-03-29T02:34:31.350Z","rankIndex":5.027724705766,"hot":false,"autoPass":false,"originalUrl":"https://juejin.im/post/5c9cb91d5188251cea0abbd7","verifyCreatedAt":"2019-03-28T14:57:56.273Z","createdAt":"2019-03-28T14:57:56.273Z","user":{"community":null,"collectedEntriesCount":13,"company":"","followersCount":10,"followeesCount":8,"role":"guest","postedPostsCount":7,"isAuthor":false,"postedEntriesCount":0,"totalCommentsCount":0,"ngxCachedTime":1553826993,"ngxCached":true,"viewedEntriesCount":38,"jobTitle":"java开发","subscribedTagsCount":7,"totalCollectionsCount":20,"username":"进击的java程序员k","avatarLarge":"https://user-gold-cdn.xitu.io/2019/3/26/169b90e6c3967879?w=500&h=375&f=jpeg&s=12988","objectId":"5ba0b3b36fb9a05cd53af3dd"},"author":"","screenshot":"","original":true,"hotIndex":516.2824,"content":"事务是MySQL等关系型数据库区别于NoSQL的重要方面，是保证数据一致性的重要手段。 MySQL博大精深，文章疏漏之处在所难免，欢迎批评指正。 事务（Transaction）是访问和更新数据库的程序执行单元；事务中可能包含一个或多个sql语句，这些语句要么都执行，要么都不执行\u2026","title":"深入学习MySQL事务：ACID特性的实现原理","lastCommentTime":"1970-01-01T00:00:00.Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":344,"summaryInfo":"事务是MYSQL等关系型数据库区别于NOSQL的重要方面，是保证数据一致性的重要手段。 MYSQL博大精深，文章疏漏之处在所难免，欢迎批评指正。 事务（Transaction）是访问和更新数据库的程序执行单元；事务中可能包含一个或多个sql语句，这些语句要么都执行，要么都不执行。作为一个关系型数据...","isCollected":false},{"collectionCount":5,"isEvent":false,"commentsCount":0,"gfw":false,"buildTime":1.5538270353283E9,"checkStatus":true,"objectId":"5c9cdd2ce51d452a7b65ffe2","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553827000,"ngxCached":true,"title":"Go","id":"555e9a80e4b00c57d9955de2"}],"updatedAt":"2019-03-29T02:37:15.324Z","rankIndex":1.7590624215548,"hot":false,"autoPass":false,"originalUrl":"https://juejin.im/post/5c9cc6376fb9a0710b727cbd","verifyCreatedAt":"2019-03-28T14:57:45.878Z","createdAt":"2019-03-28T14:57:45.878Z","user":{"community":null,"collectedEntriesCount":23,"company":"","followersCount":45,"followeesCount":7,"role":"guest","postedPostsCount":24,"isAuthor":false,"postedEntriesCount":0,"totalCommentsCount":2,"ngxCachedTime":1553826988,"ngxCached":true,"viewedEntriesCount":516,"jobTitle":"后端开发","subscribedTagsCount":5,"totalCollectionsCount":82,"username":"张君鸿","avatarLarge":"https://user-gold-cdn.xitu.io/2019/3/24/169ad882a94e4781?w=819&h=819&f=jpeg&s=199492","objectId":"5c6665476fb9a049a81fd8e9"},"author":"","screenshot":"","original":true,"hotIndex":181.2487,"content":"应该说，无论使用哪一种编程语言开发应用程序，并发编程都是复杂的，而Go语言内置的并发支持，则让Go并发编程变得很简单。 CSP，即顺序通信进程，是Go语言中原生支持的并发模型，一般使用goroutine和channel来实现，CSP的编程思想是\u201c通过通信共享内存，而不是通过共享\u2026","title":"Golang并发之共享内存变量","lastCommentTime":"1970-01-01T00:00:00.Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":129,"summaryInfo":"应该说，无论使用哪一种编程语言开发应用程序，并发编程都是复杂的，而Go语言内置的并发支持，则让Go并发编程变得很简单。 CSP，即顺序通信进程，是Go语言中原生支持的并发模型，一般使用goroutine和channel来实现，CSP的编程思想是\u201c通过通信共享内存，而不是通过共享内存来通信\u201d，因此使...","isCollected":false},{"collectionCount":4,"isEvent":false,"commentsCount":0,"gfw":false,"buildTime":1.553826714347E9,"checkStatus":true,"objectId":"5c9af354f265da60ce37b522","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553826985,"ngxCached":true,"title":"MyBatis","id":"584803e2128fe10058bede72"}],"updatedAt":"2019-03-29T02:31:54.345Z","rankIndex":1.5374390078432,"hot":false,"autoPass":false,"originalUrl":"https://juejin.im/post/5c98409fe51d4577506bb2ae","verifyCreatedAt":"2019-03-28T12:41:43.845Z","createdAt":"2019-03-28T12:41:43.845Z","user":{"community":null,"collectedEntriesCount":21,"company":"","followersCount":58,"followeesCount":21,"role":"guest","postedPostsCount":15,"isAuthor":false,"postedEntriesCount":0,"totalCommentsCount":2,"ngxCachedTime":1553827022,"ngxCached":true,"viewedEntriesCount":493,"jobTitle":"JAVA","subscribedTagsCount":4,"totalCollectionsCount":41,"username":"失控的阿甘","avatarLarge":"https://user-gold-cdn.xitu.io/2019/3/19/16994fb4b3ba028f?w=121&h=121&f=jpeg&s=11989","objectId":"5b3b4ce0e51d4519721b55a9"},"author":"","screenshot":"https://user-gold-cdn.xitu.io/2019/3/25/169b2bd958770fc3?w=703&h=301&f=png&s=15564","original":true,"hotIndex":211.2794,"content":"org.apache.ibatis.reflection.property.ObjectWrapper对象包装器接口，基于 MetaClass工具类，定义对指定对象的各种操作。类图和代码如下： org.apache.ibatis.reflection.wrapper.BaseW\u2026","title":"Mybatis技术内幕（2.3.6）：反射模块-Wrapper","lastCommentTime":"1970-01-01T00:00:00.Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":169,"summaryInfo":"2.0 OBJECTWRAPPER 对象包装器接口 对象包装器接口，基于 MetaClass工具类，定义对指定对象的各种操作。类图和代码如下： 2.1 BASEWRAPPER 基础包装器 抽象类，实现ObjectWrapper接口，为子类BeanWrapper和MapWrapper提供公共的方法和...","isCollected":false},{"collectionCount":7,"isEvent":false,"commentsCount":3,"gfw":false,"buildTime":1.5538269895353E9,"checkStatus":true,"objectId":"5c9b1ecd518825529a0c78dd","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553827057,"ngxCached":true,"title":"Spring Boot","id":"58c8ac9244d90400682037f1"}],"updatedAt":"2019-03-29T02:36:29.534Z","rankIndex":2.6158260818856,"hot":false,"autoPass":false,"originalUrl":"https://juejin.im/post/5c9b1c6be51d456303722fd2","verifyCreatedAt":"2019-03-28T12:40:19.364Z","createdAt":"2019-03-28T12:40:19.364Z","user":{"community":{"wechat":{"avatarLarge":"http://thirdwx.qlogo.cn/mmopen/vi_32/c3VrdibDx1TjxcY4wQT33qYoralsuRcibDZXCmLe4U0rHhbWR1GfHIzBxEU1icMFktCic9rvwxcib15PEKwiaYNfQyTA/132"}},"collectedEntriesCount":46,"company":"Foresee","followersCount":4,"followeesCount":30,"role":"guest","postedPostsCount":2,"isAuthor":false,"postedEntriesCount":0,"totalCommentsCount":5,"ngxCachedTime":1553826989,"ngxCached":true,"viewedEntriesCount":866,"jobTitle":"Java 工程师","subscribedTagsCount":5,"totalCollectionsCount":16,"username":"eddy_zy","avatarLarge":"https://user-gold-cdn.xitu.io/2018/12/13/167a5eb000c951e7?w=1440&h=1080&f=jpeg&s=740363","objectId":"582992060ce46300560c3edd"},"author":"","screenshot":"https://user-gold-cdn.xitu.io/2019/3/27/169bdf0b012d97e5?w=1920&h=1080&f=jpeg&s=107107","original":true,"hotIndex":359.4601,"content":"Liquibase 是一个用于跟踪、管理和应用数据库变化的开源的数据库重构工具。它将所有数据库的变化（包括结构和数据）都保存在 changelog文件中，便于版本控制，它的目标是提供一种数据库类型无关的解决方案，通过执行 schema 类型的文件来达到迁移。 支持多种运行方式，\u2026","title":"Spring Boot 简单集成 Liquibase","lastCommentTime":"2019-03-29T09:45:14.978Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":272,"summaryInfo":"是一个用于跟踪、管理和应用数据库变化的开源的数据库重构工具。它将所有数据库的变化（包括结构和数据）都保存在 文件中，便于版本控制，它的目标是提供一种数据库类型无关的解决方案，通过执行 schema 类型的文件来达到迁移。 更多详情介绍，请查阅 Liquibase 官方文档 因为 Spring Bo...","isCollected":false},{"collectionCount":23,"isEvent":false,"commentsCount":0,"gfw":false,"buildTime":1.5538270145034E9,"checkStatus":true,"objectId":"5c9ca04ae51d4512330cb166","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553827053,"ngxCached":true,"title":"面试","id":"55979fe6e4b08a686ce562fe"}],"updatedAt":"2019-03-29T02:36:54.502Z","rankIndex":7.4999818925667,"hot":false,"autoPass":false,"originalUrl":"https://juejin.im/post/5c9c9f2ae51d457d644af1e6","verifyCreatedAt":"2019-03-28T12:36:25.595Z","createdAt":"2019-03-28T12:36:25.595Z","user":{"community":null,"collectedEntriesCount":38,"company":"","followersCount":13,"followeesCount":14,"role":"guest","postedPostsCount":8,"isAuthor":false,"postedEntriesCount":0,"totalCommentsCount":0,"ngxCachedTime":1553827014,"ngxCached":true,"viewedEntriesCount":946,"jobTitle":"Java开发工程师","subscribedTagsCount":18,"totalCollectionsCount":26,"username":"码上实战","avatarLarge":"https://user-gold-cdn.xitu.io/2019/3/5/1694e2092cac380e?w=400&h=400&f=png&s=5269","objectId":"5848fc202f301e005715ee96"},"author":"","screenshot":"","original":true,"hotIndex":1037.4276,"content":"字符串广泛应用 在Java 编程中，在 Java 中字符串属于对象，Java 提供了 String 类来创建和操作字符串。 效率：1.在早期的JVM实现版本中，被final修饰的方法会被转为内嵌调用以提升执行效率。而从Java SE5/6开始，就渐渐摈弃这种方式了。因此在现在的\u2026","title":"面试别再问我String了","lastCommentTime":"1970-01-01T00:00:00.Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":805,"summaryInfo":"字符串广泛应用 在Java 编程中，在 Java 中字符串属于对象，Java 提供了 String 类来创建和操作字符串。 为了不浪费你的时间，请看下面的题目，若你一目了然，可以跳过本文了。 从上面的题中你会知道，String的创建方式有两种： 要理解String，那么要了解JVM内存中的栈(st...","isCollected":false},{"collectionCount":14,"isEvent":false,"commentsCount":0,"gfw":false,"buildTime":1.5538270360571E9,"checkStatus":true,"objectId":"5c9ca1cf5188251d7d026634","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553827065,"ngxCached":true,"title":"Redis","id":"555e9ab1e4b00c57d99560b5"}],"updatedAt":"2019-03-29T02:37:16.056Z","rankIndex":2.9094778714369,"hot":false,"autoPass":false,"originalUrl":"https://juejin.im/post/5c9ca08f5188252d5a14a31b","verifyCreatedAt":"2019-03-28T12:35:52.933Z","createdAt":"2019-03-28T12:35:52.933Z","user":{"community":null,"collectedEntriesCount":0,"company":"","followersCount":8,"followeesCount":6,"role":"guest","postedPostsCount":4,"isAuthor":false,"postedEntriesCount":0,"totalCommentsCount":0,"ngxCachedTime":1553827036,"ngxCached":true,"viewedEntriesCount":24,"jobTitle":"Java","subscribedTagsCount":1,"totalCollectionsCount":16,"username":"一角钱","avatarLarge":"https://user-gold-cdn.xitu.io/2019/3/14/1697cad68dc112ce?w=864&h=868&f=png&s=894732","objectId":"5c10d441e51d4518bd1ab37f"},"author":"","screenshot":"","original":true,"hotIndex":402.9847,"content":"我在路径/home下创建一个文件夹redis-cluster,在路径/home/redis-cluster下创建一个文件redis-cluster.tmpl，并把以下内容复制过去。（注：路径可自定义，我用的是/home/redis-cluster） 至此，集群已经创建好了。","title":"Docker Redis 5.0 集群（cluster）搭建","lastCommentTime":"1970-01-01T00:00:00.Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":260,"summaryInfo":"在DOCKER库获取REDIS镜像（截至2019-03-27，最新版为5.0.4） 至此，docker上redis cluster所有工具准备完毕，我们在命令行上输入docker images，就可以查看到已经安装的镜像 #####（1）创建redis配置文件（redis-cluster.tmpl...","isCollected":false},{"collectionCount":37,"isEvent":false,"commentsCount":8,"gfw":false,"buildTime":1.5538270220079E9,"checkStatus":true,"objectId":"5c9c8d14f265da60f30d5d17","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553827000,"ngxCached":true,"title":"Go","id":"555e9a80e4b00c57d9955de2"}],"updatedAt":"2019-03-29T02:37:02.006Z","rankIndex":7.2350839560987,"hot":false,"autoPass":false,"originalUrl":"https://juejin.im/post/5c9c8c4fe51d450bc9547ba1","verifyCreatedAt":"2019-03-28T09:48:05.356Z","createdAt":"2019-03-28T09:48:05.356Z","user":{"community":null,"collectedEntriesCount":4,"company":"","followersCount":26,"followeesCount":35,"role":"guest","postedPostsCount":4,"isAuthor":false,"postedEntriesCount":3,"totalCommentsCount":10,"ngxCachedTime":1553826979,"ngxCached":true,"viewedEntriesCount":6,"jobTitle":"","subscribedTagsCount":14,"totalCollectionsCount":67,"username":"ZetaChow晓代码","avatarLarge":"https://user-gold-cdn.xitu.io/2019/3/28/169c3886ae94e0c2?w=510&h=510&f=png&s=122629","objectId":"5c21d984e51d4522ec5a00a6"},"author":"","screenshot":"","original":true,"hotIndex":1348.9356,"content":"Go 1.11和1.12实现了对包管理的初步支持，Go的新依赖管理系统使依赖版本信息明确且易于管理。 作为Go语言的推广者，常常被问到各种关于Go语言的基础特性问题。 其中，关于包管理方面的问题会让我非常尴尬，因为Go的包管理在1.11之前与Python、Node、Java比较\u2026","title":"拜拜了，GOPATH君！新版本Golang的包管理入门教程","lastCommentTime":"2019-03-29T00:05:18.099Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":936,"summaryInfo":"Go 1.11和1.12实现了对包管理的初步支持，Go的新依赖管理系统使依赖版本信息明确且易于管理。Using Go Modules - The Go Blog 作为Go语言的推广者，常常被问到各种关于Go语言的基础特性问题。其中，关于包管理方面的问题会让我非常尴尬，因为Go的包管理在1.11之前...","isCollected":false}]}
     */

    private int s;
    private String m;
    private DBean d;

    public int getS() {
        return s;
    }

    public void setS(int s) {
        this.s = s;
    }

    public String getM() {
        return m;
    }

    public void setM(String m) {
        this.m = m;
    }

    public DBean getD() {
        return d;
    }

    public void setD(DBean d) {
        this.d = d;
    }

    public static class DBean {
        /**
         * total : 10
         * entrylist : [{"collectionCount":5,"isEvent":false,"commentsCount":0,"gfw":false,"buildTime":1.5538270211392E9,"checkStatus":true,"objectId":"5c9d78a96fb9a070d0141255","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553826996,"ngxCached":true,"title":"后端","id":"5597a063e4b08a686ce57030"},{"ngxCachedTime":1553826980,"ngxCached":true,"title":"Java","id":"559a7207e4b08a686d25703e"}],"updatedAt":"2019-03-29T02:37:01.137Z","rankIndex":94.268749986838,"hot":false,"autoPass":true,"originalUrl":"https://juejin.im/post/5c9d78715188251e3e3c8a7f","verifyCreatedAt":"2019-03-29T01:45:13.966Z","createdAt":"2019-03-29T01:45:13.966Z","user":{"community":{"github":{"username":"dyc87112","avatarLarge":"https://avatars0.githubusercontent.com/u/3391170?v=4","uid":"3391170"}},"collectedEntriesCount":23,"company":"关注我，每日技术干货推送，每月福利免费领取！","followersCount":2786,"followeesCount":6,"role":"editor","postedPostsCount":41,"isAuthor":false,"postedEntriesCount":40,"totalCommentsCount":47,"ngxCachedTime":1553827021,"ngxCached":true,"viewedEntriesCount":120,"jobTitle":"","subscribedTagsCount":29,"totalCollectionsCount":781,"username":"程序猿DD_","avatarLarge":"https://user-gold-cdn.xitu.io/2019/3/21/1699f0e5d13e9789?w=568&h=568&f=jpeg&s=33909","objectId":"58e10d35570c350057a277bc"},"author":"","screenshot":"","original":true,"hotIndex":422.0601,"content":"最近对《Spring Cloud Alibaba基础教程》系列的催更比较多，说一下最近的近况：因为打算Spring Boot 2.x一起更新。所以一直在改博客Spring Boot专题页和Git仓库的组织。由于前端技术太过蹩脚，花了不少时间。大家不用担心，这个系列不会太监，因为\u2026","title":"说说我为什么看好Spring Cloud Alibaba","lastCommentTime":"1970-01-01T00:00:00.Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":370,"summaryInfo":"最近对《Spring Cloud Alibaba基础教程》系列的催更比较多，说一下最近的近况：因为打算Spring Boot 2.x一起更新。所以一直在改博客Spring Boot专题页和Git仓库的组织。由于前端技术太过蹩脚，花了不少时间。大家不用担心，这个系列不会太监，因为我真心看好这个套件的...","isCollected":false},{"collectionCount":11,"isEvent":false,"commentsCount":0,"gfw":false,"buildTime":1.5538270171562E9,"checkStatus":true,"objectId":"5c9d57435188252d5c745326","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553827000,"ngxCached":true,"title":"Go","id":"555e9a80e4b00c57d9955de2"}],"updatedAt":"2019-03-29T02:36:57.155Z","rankIndex":28.460316899721,"hot":false,"autoPass":true,"originalUrl":"https://juejin.im/post/5c9d5631f265da60d82dde9c","verifyCreatedAt":"2019-03-28T23:22:43.559Z","createdAt":"2019-03-28T23:22:43.559Z","user":{"community":null,"collectedEntriesCount":88,"company":"公众号：Golang来啦","followersCount":191,"followeesCount":20,"role":"editor","postedPostsCount":19,"isAuthor":false,"postedEntriesCount":7,"totalCommentsCount":14,"ngxCachedTime":1553826950,"ngxCached":true,"viewedEntriesCount":1289,"jobTitle":"","subscribedTagsCount":67,"totalCollectionsCount":334,"username":"Seekload","avatarLarge":"https://user-gold-cdn.xitu.io/2018/11/20/1673082d8c30d80d?w=225&h=225&f=png&s=4504","objectId":"573730741532bc006548416a"},"author":"","screenshot":"https://user-gold-cdn.xitu.io/2019/3/29/169c69c932711a62?w=1000&h=666&f=jpeg&s=65444","original":true,"hotIndex":460.0793,"content":"在一些面向对象的编程语言中，例如 Java、PHP 等，接口定义了对象的行为，只指定了对象应该做什么。行为的具体实现取决于对象。 在 Go 语言中，接口是一组方法的集合，但不包含方法的实现、是抽象的，接口中也不能包含变量。当一个类型 T 提供了接口中所有方法的定义时，就说 T \u2026","title":"Go 语言接口详解（一）","lastCommentTime":"1970-01-01T00:00:00.Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":348,"summaryInfo":"在一些面向对象的编程语言中，例如 Java、PHP 等，接口定义了对象的行为，只指定了对象应该做什么。行为的具体实现取决于对象。 在 Go 语言中，接口是一组方法的集合，但不包含方法的实现、是抽象的，接口中也不能包含变量。当一个类型 T 提供了接口中所有方法的定义时，就说 T 实现了接口。接口指定...","isCollected":false},{"collectionCount":3,"isEvent":false,"commentsCount":0,"gfw":false,"buildTime":1.5538270351365E9,"checkStatus":true,"objectId":"5c9cdde46fb9a070fc62516f","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553826952,"ngxCached":true,"title":"Spring","id":"5847c9a5ac502e006ce63fa1"}],"updatedAt":"2019-03-29T02:37:15.135Z","rankIndex":1.2119021773034,"hot":false,"autoPass":false,"originalUrl":"https://juejin.im/post/5c9cdcf06fb9a070cb24c4d1","verifyCreatedAt":"2019-03-28T14:58:10.827Z","createdAt":"2019-03-28T14:58:10.827Z","user":{"community":{"weibo":{"selfDescription":"实施搬过砖，银行打过杂，倒闭卖公司，投机又倒把。","uid":"1144349627","blogAddress":"http://weibo.com/akirapanda","username":"废柴大叔阿基拉","avatarLarge":"http://tva4.sinaimg.cn/crop.0.0.180.180.180/443563bbjw1e8qgp5bmzyj2050050aa8.jpg"}},"collectedEntriesCount":2,"company":"","followersCount":28,"followeesCount":32,"role":"guest","postedPostsCount":5,"isAuthor":false,"postedEntriesCount":0,"totalCommentsCount":5,"ngxCachedTime":1553827042,"ngxCached":true,"viewedEntriesCount":62,"jobTitle":"咨询工程师","subscribedTagsCount":2,"totalCollectionsCount":23,"username":"废柴大叔阿基拉","avatarLarge":"https://user-gold-cdn.xitu.io/2019/3/25/169b46cc8fe5df08?w=454&h=454&f=jpeg&s=19650","objectId":"5c98aef96fb9a071105de2f6"},"author":"","screenshot":"","original":true,"hotIndex":125.0634,"content":"我们在某一期其实已经对Authentication身份验证中的主要组件进行过介绍，并且通过几期的分享让大家大致了解了Web应用大致利用核心进行身份验证的流程和相关的扩展点。 这一期我们用一期的篇章把关注点放在Authentication身份验证核心最主要的几个服务Authent\u2026","title":"Spring Security小教程 Vol 5.核心组件AuthenticationManager专题","lastCommentTime":"1970-01-01T00:00:00.Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":93,"summaryInfo":"我们在某一期其实已经对身份验证中的主要组件进行过介绍，并且通过几期的分享让大家大致了解了Web应用大致利用核心进行身份验证的流程和相关的扩展点。这一期我们用一期的篇章把关注点放在身份验证核心最主要的几个服务、和，三个顶层接口进行展开。通过Spring Security对这些接口服务的实现进行说明讲...","isCollected":false},{"collectionCount":17,"isEvent":false,"commentsCount":0,"gfw":false,"buildTime":1.553826871352E9,"checkStatus":true,"objectId":"5c9cd4546fb9a071071947bf","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553826980,"ngxCached":true,"title":"Java","id":"559a7207e4b08a686d25703e"}],"updatedAt":"2019-03-29T02:34:31.350Z","rankIndex":5.027724705766,"hot":false,"autoPass":false,"originalUrl":"https://juejin.im/post/5c9cb91d5188251cea0abbd7","verifyCreatedAt":"2019-03-28T14:57:56.273Z","createdAt":"2019-03-28T14:57:56.273Z","user":{"community":null,"collectedEntriesCount":13,"company":"","followersCount":10,"followeesCount":8,"role":"guest","postedPostsCount":7,"isAuthor":false,"postedEntriesCount":0,"totalCommentsCount":0,"ngxCachedTime":1553826993,"ngxCached":true,"viewedEntriesCount":38,"jobTitle":"java开发","subscribedTagsCount":7,"totalCollectionsCount":20,"username":"进击的java程序员k","avatarLarge":"https://user-gold-cdn.xitu.io/2019/3/26/169b90e6c3967879?w=500&h=375&f=jpeg&s=12988","objectId":"5ba0b3b36fb9a05cd53af3dd"},"author":"","screenshot":"","original":true,"hotIndex":516.2824,"content":"事务是MySQL等关系型数据库区别于NoSQL的重要方面，是保证数据一致性的重要手段。 MySQL博大精深，文章疏漏之处在所难免，欢迎批评指正。 事务（Transaction）是访问和更新数据库的程序执行单元；事务中可能包含一个或多个sql语句，这些语句要么都执行，要么都不执行\u2026","title":"深入学习MySQL事务：ACID特性的实现原理","lastCommentTime":"1970-01-01T00:00:00.Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":344,"summaryInfo":"事务是MYSQL等关系型数据库区别于NOSQL的重要方面，是保证数据一致性的重要手段。 MYSQL博大精深，文章疏漏之处在所难免，欢迎批评指正。 事务（Transaction）是访问和更新数据库的程序执行单元；事务中可能包含一个或多个sql语句，这些语句要么都执行，要么都不执行。作为一个关系型数据...","isCollected":false},{"collectionCount":5,"isEvent":false,"commentsCount":0,"gfw":false,"buildTime":1.5538270353283E9,"checkStatus":true,"objectId":"5c9cdd2ce51d452a7b65ffe2","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553827000,"ngxCached":true,"title":"Go","id":"555e9a80e4b00c57d9955de2"}],"updatedAt":"2019-03-29T02:37:15.324Z","rankIndex":1.7590624215548,"hot":false,"autoPass":false,"originalUrl":"https://juejin.im/post/5c9cc6376fb9a0710b727cbd","verifyCreatedAt":"2019-03-28T14:57:45.878Z","createdAt":"2019-03-28T14:57:45.878Z","user":{"community":null,"collectedEntriesCount":23,"company":"","followersCount":45,"followeesCount":7,"role":"guest","postedPostsCount":24,"isAuthor":false,"postedEntriesCount":0,"totalCommentsCount":2,"ngxCachedTime":1553826988,"ngxCached":true,"viewedEntriesCount":516,"jobTitle":"后端开发","subscribedTagsCount":5,"totalCollectionsCount":82,"username":"张君鸿","avatarLarge":"https://user-gold-cdn.xitu.io/2019/3/24/169ad882a94e4781?w=819&h=819&f=jpeg&s=199492","objectId":"5c6665476fb9a049a81fd8e9"},"author":"","screenshot":"","original":true,"hotIndex":181.2487,"content":"应该说，无论使用哪一种编程语言开发应用程序，并发编程都是复杂的，而Go语言内置的并发支持，则让Go并发编程变得很简单。 CSP，即顺序通信进程，是Go语言中原生支持的并发模型，一般使用goroutine和channel来实现，CSP的编程思想是\u201c通过通信共享内存，而不是通过共享\u2026","title":"Golang并发之共享内存变量","lastCommentTime":"1970-01-01T00:00:00.Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":129,"summaryInfo":"应该说，无论使用哪一种编程语言开发应用程序，并发编程都是复杂的，而Go语言内置的并发支持，则让Go并发编程变得很简单。 CSP，即顺序通信进程，是Go语言中原生支持的并发模型，一般使用goroutine和channel来实现，CSP的编程思想是\u201c通过通信共享内存，而不是通过共享内存来通信\u201d，因此使...","isCollected":false},{"collectionCount":4,"isEvent":false,"commentsCount":0,"gfw":false,"buildTime":1.553826714347E9,"checkStatus":true,"objectId":"5c9af354f265da60ce37b522","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553826985,"ngxCached":true,"title":"MyBatis","id":"584803e2128fe10058bede72"}],"updatedAt":"2019-03-29T02:31:54.345Z","rankIndex":1.5374390078432,"hot":false,"autoPass":false,"originalUrl":"https://juejin.im/post/5c98409fe51d4577506bb2ae","verifyCreatedAt":"2019-03-28T12:41:43.845Z","createdAt":"2019-03-28T12:41:43.845Z","user":{"community":null,"collectedEntriesCount":21,"company":"","followersCount":58,"followeesCount":21,"role":"guest","postedPostsCount":15,"isAuthor":false,"postedEntriesCount":0,"totalCommentsCount":2,"ngxCachedTime":1553827022,"ngxCached":true,"viewedEntriesCount":493,"jobTitle":"JAVA","subscribedTagsCount":4,"totalCollectionsCount":41,"username":"失控的阿甘","avatarLarge":"https://user-gold-cdn.xitu.io/2019/3/19/16994fb4b3ba028f?w=121&h=121&f=jpeg&s=11989","objectId":"5b3b4ce0e51d4519721b55a9"},"author":"","screenshot":"https://user-gold-cdn.xitu.io/2019/3/25/169b2bd958770fc3?w=703&h=301&f=png&s=15564","original":true,"hotIndex":211.2794,"content":"org.apache.ibatis.reflection.property.ObjectWrapper对象包装器接口，基于 MetaClass工具类，定义对指定对象的各种操作。类图和代码如下： org.apache.ibatis.reflection.wrapper.BaseW\u2026","title":"Mybatis技术内幕（2.3.6）：反射模块-Wrapper","lastCommentTime":"1970-01-01T00:00:00.Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":169,"summaryInfo":"2.0 OBJECTWRAPPER 对象包装器接口 对象包装器接口，基于 MetaClass工具类，定义对指定对象的各种操作。类图和代码如下： 2.1 BASEWRAPPER 基础包装器 抽象类，实现ObjectWrapper接口，为子类BeanWrapper和MapWrapper提供公共的方法和...","isCollected":false},{"collectionCount":7,"isEvent":false,"commentsCount":3,"gfw":false,"buildTime":1.5538269895353E9,"checkStatus":true,"objectId":"5c9b1ecd518825529a0c78dd","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553827057,"ngxCached":true,"title":"Spring Boot","id":"58c8ac9244d90400682037f1"}],"updatedAt":"2019-03-29T02:36:29.534Z","rankIndex":2.6158260818856,"hot":false,"autoPass":false,"originalUrl":"https://juejin.im/post/5c9b1c6be51d456303722fd2","verifyCreatedAt":"2019-03-28T12:40:19.364Z","createdAt":"2019-03-28T12:40:19.364Z","user":{"community":{"wechat":{"avatarLarge":"http://thirdwx.qlogo.cn/mmopen/vi_32/c3VrdibDx1TjxcY4wQT33qYoralsuRcibDZXCmLe4U0rHhbWR1GfHIzBxEU1icMFktCic9rvwxcib15PEKwiaYNfQyTA/132"}},"collectedEntriesCount":46,"company":"Foresee","followersCount":4,"followeesCount":30,"role":"guest","postedPostsCount":2,"isAuthor":false,"postedEntriesCount":0,"totalCommentsCount":5,"ngxCachedTime":1553826989,"ngxCached":true,"viewedEntriesCount":866,"jobTitle":"Java 工程师","subscribedTagsCount":5,"totalCollectionsCount":16,"username":"eddy_zy","avatarLarge":"https://user-gold-cdn.xitu.io/2018/12/13/167a5eb000c951e7?w=1440&h=1080&f=jpeg&s=740363","objectId":"582992060ce46300560c3edd"},"author":"","screenshot":"https://user-gold-cdn.xitu.io/2019/3/27/169bdf0b012d97e5?w=1920&h=1080&f=jpeg&s=107107","original":true,"hotIndex":359.4601,"content":"Liquibase 是一个用于跟踪、管理和应用数据库变化的开源的数据库重构工具。它将所有数据库的变化（包括结构和数据）都保存在 changelog文件中，便于版本控制，它的目标是提供一种数据库类型无关的解决方案，通过执行 schema 类型的文件来达到迁移。 支持多种运行方式，\u2026","title":"Spring Boot 简单集成 Liquibase","lastCommentTime":"2019-03-29T09:45:14.978Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":272,"summaryInfo":"是一个用于跟踪、管理和应用数据库变化的开源的数据库重构工具。它将所有数据库的变化（包括结构和数据）都保存在 文件中，便于版本控制，它的目标是提供一种数据库类型无关的解决方案，通过执行 schema 类型的文件来达到迁移。 更多详情介绍，请查阅 Liquibase 官方文档 因为 Spring Bo...","isCollected":false},{"collectionCount":23,"isEvent":false,"commentsCount":0,"gfw":false,"buildTime":1.5538270145034E9,"checkStatus":true,"objectId":"5c9ca04ae51d4512330cb166","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553827053,"ngxCached":true,"title":"面试","id":"55979fe6e4b08a686ce562fe"}],"updatedAt":"2019-03-29T02:36:54.502Z","rankIndex":7.4999818925667,"hot":false,"autoPass":false,"originalUrl":"https://juejin.im/post/5c9c9f2ae51d457d644af1e6","verifyCreatedAt":"2019-03-28T12:36:25.595Z","createdAt":"2019-03-28T12:36:25.595Z","user":{"community":null,"collectedEntriesCount":38,"company":"","followersCount":13,"followeesCount":14,"role":"guest","postedPostsCount":8,"isAuthor":false,"postedEntriesCount":0,"totalCommentsCount":0,"ngxCachedTime":1553827014,"ngxCached":true,"viewedEntriesCount":946,"jobTitle":"Java开发工程师","subscribedTagsCount":18,"totalCollectionsCount":26,"username":"码上实战","avatarLarge":"https://user-gold-cdn.xitu.io/2019/3/5/1694e2092cac380e?w=400&h=400&f=png&s=5269","objectId":"5848fc202f301e005715ee96"},"author":"","screenshot":"","original":true,"hotIndex":1037.4276,"content":"字符串广泛应用 在Java 编程中，在 Java 中字符串属于对象，Java 提供了 String 类来创建和操作字符串。 效率：1.在早期的JVM实现版本中，被final修饰的方法会被转为内嵌调用以提升执行效率。而从Java SE5/6开始，就渐渐摈弃这种方式了。因此在现在的\u2026","title":"面试别再问我String了","lastCommentTime":"1970-01-01T00:00:00.Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":805,"summaryInfo":"字符串广泛应用 在Java 编程中，在 Java 中字符串属于对象，Java 提供了 String 类来创建和操作字符串。 为了不浪费你的时间，请看下面的题目，若你一目了然，可以跳过本文了。 从上面的题中你会知道，String的创建方式有两种： 要理解String，那么要了解JVM内存中的栈(st...","isCollected":false},{"collectionCount":14,"isEvent":false,"commentsCount":0,"gfw":false,"buildTime":1.5538270360571E9,"checkStatus":true,"objectId":"5c9ca1cf5188251d7d026634","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553827065,"ngxCached":true,"title":"Redis","id":"555e9ab1e4b00c57d99560b5"}],"updatedAt":"2019-03-29T02:37:16.056Z","rankIndex":2.9094778714369,"hot":false,"autoPass":false,"originalUrl":"https://juejin.im/post/5c9ca08f5188252d5a14a31b","verifyCreatedAt":"2019-03-28T12:35:52.933Z","createdAt":"2019-03-28T12:35:52.933Z","user":{"community":null,"collectedEntriesCount":0,"company":"","followersCount":8,"followeesCount":6,"role":"guest","postedPostsCount":4,"isAuthor":false,"postedEntriesCount":0,"totalCommentsCount":0,"ngxCachedTime":1553827036,"ngxCached":true,"viewedEntriesCount":24,"jobTitle":"Java","subscribedTagsCount":1,"totalCollectionsCount":16,"username":"一角钱","avatarLarge":"https://user-gold-cdn.xitu.io/2019/3/14/1697cad68dc112ce?w=864&h=868&f=png&s=894732","objectId":"5c10d441e51d4518bd1ab37f"},"author":"","screenshot":"","original":true,"hotIndex":402.9847,"content":"我在路径/home下创建一个文件夹redis-cluster,在路径/home/redis-cluster下创建一个文件redis-cluster.tmpl，并把以下内容复制过去。（注：路径可自定义，我用的是/home/redis-cluster） 至此，集群已经创建好了。","title":"Docker Redis 5.0 集群（cluster）搭建","lastCommentTime":"1970-01-01T00:00:00.Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":260,"summaryInfo":"在DOCKER库获取REDIS镜像（截至2019-03-27，最新版为5.0.4） 至此，docker上redis cluster所有工具准备完毕，我们在命令行上输入docker images，就可以查看到已经安装的镜像 #####（1）创建redis配置文件（redis-cluster.tmpl...","isCollected":false},{"collectionCount":37,"isEvent":false,"commentsCount":8,"gfw":false,"buildTime":1.5538270220079E9,"checkStatus":true,"objectId":"5c9c8d14f265da60f30d5d17","entryView":"","subscribersCount":0,"ngxCachedTime":1553827069,"verifyStatus":true,"tags":[{"ngxCachedTime":1553827000,"ngxCached":true,"title":"Go","id":"555e9a80e4b00c57d9955de2"}],"updatedAt":"2019-03-29T02:37:02.006Z","rankIndex":7.2350839560987,"hot":false,"autoPass":false,"originalUrl":"https://juejin.im/post/5c9c8c4fe51d450bc9547ba1","verifyCreatedAt":"2019-03-28T09:48:05.356Z","createdAt":"2019-03-28T09:48:05.356Z","user":{"community":null,"collectedEntriesCount":4,"company":"","followersCount":26,"followeesCount":35,"role":"guest","postedPostsCount":4,"isAuthor":false,"postedEntriesCount":3,"totalCommentsCount":10,"ngxCachedTime":1553826979,"ngxCached":true,"viewedEntriesCount":6,"jobTitle":"","subscribedTagsCount":14,"totalCollectionsCount":67,"username":"ZetaChow晓代码","avatarLarge":"https://user-gold-cdn.xitu.io/2019/3/28/169c3886ae94e0c2?w=510&h=510&f=png&s=122629","objectId":"5c21d984e51d4522ec5a00a6"},"author":"","screenshot":"","original":true,"hotIndex":1348.9356,"content":"Go 1.11和1.12实现了对包管理的初步支持，Go的新依赖管理系统使依赖版本信息明确且易于管理。 作为Go语言的推广者，常常被问到各种关于Go语言的基础特性问题。 其中，关于包管理方面的问题会让我非常尴尬，因为Go的包管理在1.11之前与Python、Node、Java比较\u2026","title":"拜拜了，GOPATH君！新版本Golang的包管理入门教程","lastCommentTime":"2019-03-29T00:05:18.099Z","type":"post","english":false,"category":{"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952},"viewsCount":936,"summaryInfo":"Go 1.11和1.12实现了对包管理的初步支持，Go的新依赖管理系统使依赖版本信息明确且易于管理。Using Go Modules - The Go Blog 作为Go语言的推广者，常常被问到各种关于Go语言的基础特性问题。其中，关于包管理方面的问题会让我非常尴尬，因为Go的包管理在1.11之前...","isCollected":false}]
         */

        private int total;
        private List<EntrylistBean> entrylist;

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public List<EntrylistBean> getEntrylist() {
            return entrylist;
        }

        public void setEntrylist(List<EntrylistBean> entrylist) {
            this.entrylist = entrylist;
        }

        public static class EntrylistBean {
            /**
             * collectionCount : 5
             * isEvent : false
             * commentsCount : 0
             * gfw : false
             * buildTime : 1.5538270211392E9
             * checkStatus : true
             * objectId : 5c9d78a96fb9a070d0141255
             * entryView :
             * subscribersCount : 0
             * ngxCachedTime : 1553827069
             * verifyStatus : true
             * tags : [{"ngxCachedTime":1553826996,"ngxCached":true,"title":"后端","id":"5597a063e4b08a686ce57030"},{"ngxCachedTime":1553826980,"ngxCached":true,"title":"Java","id":"559a7207e4b08a686d25703e"}]
             * updatedAt : 2019-03-29T02:37:01.137Z
             * rankIndex : 94.268749986838
             * hot : false
             * autoPass : true
             * originalUrl : https://juejin.im/post/5c9d78715188251e3e3c8a7f
             * verifyCreatedAt : 2019-03-29T01:45:13.966Z
             * createdAt : 2019-03-29T01:45:13.966Z
             * user : {"community":{"github":{"username":"dyc87112","avatarLarge":"https://avatars0.githubusercontent.com/u/3391170?v=4","uid":"3391170"}},"collectedEntriesCount":23,"company":"关注我，每日技术干货推送，每月福利免费领取！","followersCount":2786,"followeesCount":6,"role":"editor","postedPostsCount":41,"isAuthor":false,"postedEntriesCount":40,"totalCommentsCount":47,"ngxCachedTime":1553827021,"ngxCached":true,"viewedEntriesCount":120,"jobTitle":"","subscribedTagsCount":29,"totalCollectionsCount":781,"username":"程序猿DD_","avatarLarge":"https://user-gold-cdn.xitu.io/2019/3/21/1699f0e5d13e9789?w=568&h=568&f=jpeg&s=33909","objectId":"58e10d35570c350057a277bc"}
             * author :
             * screenshot :
             * original : true
             * hotIndex : 422.0601
             * content : 最近对《Spring Cloud Alibaba基础教程》系列的催更比较多，说一下最近的近况：因为打算Spring Boot 2.x一起更新。所以一直在改博客Spring Boot专题页和Git仓库的组织。由于前端技术太过蹩脚，花了不少时间。大家不用担心，这个系列不会太监，因为…
             * title : 说说我为什么看好Spring Cloud Alibaba
             * lastCommentTime : 1970-01-01T00:00:00.Z
             * type : post
             * english : false
             * category : {"ngxCached":true,"title":"backend","id":"5562b419e4b00c57d9b94ae2","name":"后端","ngxCachedTime":1553826952}
             * viewsCount : 370
             * summaryInfo : 最近对《Spring Cloud Alibaba基础教程》系列的催更比较多，说一下最近的近况：因为打算Spring Boot 2.x一起更新。所以一直在改博客Spring Boot专题页和Git仓库的组织。由于前端技术太过蹩脚，花了不少时间。大家不用担心，这个系列不会太监，因为我真心看好这个套件的...
             * isCollected : false
             */

            private int collectionCount;
            private boolean isEvent;
            private int commentsCount;
            private boolean gfw;
            private double buildTime;
            private boolean checkStatus;
            private String objectId;
            private String entryView;
            private int subscribersCount;
            private int ngxCachedTime;
            private boolean verifyStatus;
            private String updatedAt;
            private double rankIndex;
            private boolean hot;
            private boolean autoPass;
            private String originalUrl;
            private String verifyCreatedAt;
            private String createdAt;
            private UserBean user;
            private String author;
            private String screenshot;
            private boolean original;
            private double hotIndex;
            private String content;
            private String title;
            private String lastCommentTime;
            private String type;
            private boolean english;
            private CategoryBean category;
            private int viewsCount;
            private String summaryInfo;
            private boolean isCollected;
            private List<TagsBean> tags;

            public int getCollectionCount() {
                return collectionCount;
            }

            public void setCollectionCount(int collectionCount) {
                this.collectionCount = collectionCount;
            }

            public boolean isIsEvent() {
                return isEvent;
            }

            public void setIsEvent(boolean isEvent) {
                this.isEvent = isEvent;
            }

            public int getCommentsCount() {
                return commentsCount;
            }

            public void setCommentsCount(int commentsCount) {
                this.commentsCount = commentsCount;
            }

            public boolean isGfw() {
                return gfw;
            }

            public void setGfw(boolean gfw) {
                this.gfw = gfw;
            }

            public double getBuildTime() {
                return buildTime;
            }

            public void setBuildTime(double buildTime) {
                this.buildTime = buildTime;
            }

            public boolean isCheckStatus() {
                return checkStatus;
            }

            public void setCheckStatus(boolean checkStatus) {
                this.checkStatus = checkStatus;
            }

            public String getObjectId() {
                return objectId;
            }

            public void setObjectId(String objectId) {
                this.objectId = objectId;
            }

            public String getEntryView() {
                return entryView;
            }

            public void setEntryView(String entryView) {
                this.entryView = entryView;
            }

            public int getSubscribersCount() {
                return subscribersCount;
            }

            public void setSubscribersCount(int subscribersCount) {
                this.subscribersCount = subscribersCount;
            }

            public int getNgxCachedTime() {
                return ngxCachedTime;
            }

            public void setNgxCachedTime(int ngxCachedTime) {
                this.ngxCachedTime = ngxCachedTime;
            }

            public boolean isVerifyStatus() {
                return verifyStatus;
            }

            public void setVerifyStatus(boolean verifyStatus) {
                this.verifyStatus = verifyStatus;
            }

            public String getUpdatedAt() {
                return updatedAt;
            }

            public void setUpdatedAt(String updatedAt) {
                this.updatedAt = updatedAt;
            }

            public double getRankIndex() {
                return rankIndex;
            }

            public void setRankIndex(double rankIndex) {
                this.rankIndex = rankIndex;
            }

            public boolean isHot() {
                return hot;
            }

            public void setHot(boolean hot) {
                this.hot = hot;
            }

            public boolean isAutoPass() {
                return autoPass;
            }

            public void setAutoPass(boolean autoPass) {
                this.autoPass = autoPass;
            }

            public String getOriginalUrl() {
                return originalUrl;
            }

            public void setOriginalUrl(String originalUrl) {
                this.originalUrl = originalUrl;
            }

            public String getVerifyCreatedAt() {
                return verifyCreatedAt;
            }

            public void setVerifyCreatedAt(String verifyCreatedAt) {
                this.verifyCreatedAt = verifyCreatedAt;
            }

            public String getCreatedAt() {
                return createdAt;
            }

            public void setCreatedAt(String createdAt) {
                this.createdAt = createdAt;
            }

            public UserBean getUser() {
                return user;
            }

            public void setUser(UserBean user) {
                this.user = user;
            }

            public String getAuthor() {
                return author;
            }

            public void setAuthor(String author) {
                this.author = author;
            }

            public String getScreenshot() {
                return screenshot;
            }

            public void setScreenshot(String screenshot) {
                this.screenshot = screenshot;
            }

            public boolean isOriginal() {
                return original;
            }

            public void setOriginal(boolean original) {
                this.original = original;
            }

            public double getHotIndex() {
                return hotIndex;
            }

            public void setHotIndex(double hotIndex) {
                this.hotIndex = hotIndex;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getLastCommentTime() {
                return lastCommentTime;
            }

            public void setLastCommentTime(String lastCommentTime) {
                this.lastCommentTime = lastCommentTime;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public boolean isEnglish() {
                return english;
            }

            public void setEnglish(boolean english) {
                this.english = english;
            }

            public CategoryBean getCategory() {
                return category;
            }

            public void setCategory(CategoryBean category) {
                this.category = category;
            }

            public int getViewsCount() {
                return viewsCount;
            }

            public void setViewsCount(int viewsCount) {
                this.viewsCount = viewsCount;
            }

            public String getSummaryInfo() {
                return summaryInfo;
            }

            public void setSummaryInfo(String summaryInfo) {
                this.summaryInfo = summaryInfo;
            }

            public boolean isIsCollected() {
                return isCollected;
            }

            public void setIsCollected(boolean isCollected) {
                this.isCollected = isCollected;
            }

            public List<TagsBean> getTags() {
                return tags;
            }

            public void setTags(List<TagsBean> tags) {
                this.tags = tags;
            }

            public static class UserBean {
                /**
                 * community : {"github":{"username":"dyc87112","avatarLarge":"https://avatars0.githubusercontent.com/u/3391170?v=4","uid":"3391170"}}
                 * collectedEntriesCount : 23
                 * company : 关注我，每日技术干货推送，每月福利免费领取！
                 * followersCount : 2786
                 * followeesCount : 6
                 * role : editor
                 * postedPostsCount : 41
                 * isAuthor : false
                 * postedEntriesCount : 40
                 * totalCommentsCount : 47
                 * ngxCachedTime : 1553827021
                 * ngxCached : true
                 * viewedEntriesCount : 120
                 * jobTitle :
                 * subscribedTagsCount : 29
                 * totalCollectionsCount : 781
                 * username : 程序猿DD_
                 * avatarLarge : https://user-gold-cdn.xitu.io/2019/3/21/1699f0e5d13e9789?w=568&h=568&f=jpeg&s=33909
                 * objectId : 58e10d35570c350057a277bc
                 */

                private CommunityBean community;
                private int collectedEntriesCount;
                private String company;
                private int followersCount;
                private int followeesCount;
                private String role;
                private int postedPostsCount;
                private boolean isAuthor;
                private int postedEntriesCount;
                private int totalCommentsCount;
                private int ngxCachedTime;
                private boolean ngxCached;
                private int viewedEntriesCount;
                private String jobTitle;
                private int subscribedTagsCount;
                private int totalCollectionsCount;
                private String username;
                private String avatarLarge;
                private String objectId;

                public CommunityBean getCommunity() {
                    return community;
                }

                public void setCommunity(CommunityBean community) {
                    this.community = community;
                }

                public int getCollectedEntriesCount() {
                    return collectedEntriesCount;
                }

                public void setCollectedEntriesCount(int collectedEntriesCount) {
                    this.collectedEntriesCount = collectedEntriesCount;
                }

                public String getCompany() {
                    return company;
                }

                public void setCompany(String company) {
                    this.company = company;
                }

                public int getFollowersCount() {
                    return followersCount;
                }

                public void setFollowersCount(int followersCount) {
                    this.followersCount = followersCount;
                }

                public int getFolloweesCount() {
                    return followeesCount;
                }

                public void setFolloweesCount(int followeesCount) {
                    this.followeesCount = followeesCount;
                }

                public String getRole() {
                    return role;
                }

                public void setRole(String role) {
                    this.role = role;
                }

                public int getPostedPostsCount() {
                    return postedPostsCount;
                }

                public void setPostedPostsCount(int postedPostsCount) {
                    this.postedPostsCount = postedPostsCount;
                }

                public boolean isIsAuthor() {
                    return isAuthor;
                }

                public void setIsAuthor(boolean isAuthor) {
                    this.isAuthor = isAuthor;
                }

                public int getPostedEntriesCount() {
                    return postedEntriesCount;
                }

                public void setPostedEntriesCount(int postedEntriesCount) {
                    this.postedEntriesCount = postedEntriesCount;
                }

                public int getTotalCommentsCount() {
                    return totalCommentsCount;
                }

                public void setTotalCommentsCount(int totalCommentsCount) {
                    this.totalCommentsCount = totalCommentsCount;
                }

                public int getNgxCachedTime() {
                    return ngxCachedTime;
                }

                public void setNgxCachedTime(int ngxCachedTime) {
                    this.ngxCachedTime = ngxCachedTime;
                }

                public boolean isNgxCached() {
                    return ngxCached;
                }

                public void setNgxCached(boolean ngxCached) {
                    this.ngxCached = ngxCached;
                }

                public int getViewedEntriesCount() {
                    return viewedEntriesCount;
                }

                public void setViewedEntriesCount(int viewedEntriesCount) {
                    this.viewedEntriesCount = viewedEntriesCount;
                }

                public String getJobTitle() {
                    return jobTitle;
                }

                public void setJobTitle(String jobTitle) {
                    this.jobTitle = jobTitle;
                }

                public int getSubscribedTagsCount() {
                    return subscribedTagsCount;
                }

                public void setSubscribedTagsCount(int subscribedTagsCount) {
                    this.subscribedTagsCount = subscribedTagsCount;
                }

                public int getTotalCollectionsCount() {
                    return totalCollectionsCount;
                }

                public void setTotalCollectionsCount(int totalCollectionsCount) {
                    this.totalCollectionsCount = totalCollectionsCount;
                }

                public String getUsername() {
                    return username;
                }

                public void setUsername(String username) {
                    this.username = username;
                }

                public String getAvatarLarge() {
                    return avatarLarge;
                }

                public void setAvatarLarge(String avatarLarge) {
                    this.avatarLarge = avatarLarge;
                }

                public String getObjectId() {
                    return objectId;
                }

                public void setObjectId(String objectId) {
                    this.objectId = objectId;
                }

                public static class CommunityBean {
                    /**
                     * github : {"username":"dyc87112","avatarLarge":"https://avatars0.githubusercontent.com/u/3391170?v=4","uid":"3391170"}
                     */

                    private GithubBean github;

                    public GithubBean getGithub() {
                        return github;
                    }

                    public void setGithub(GithubBean github) {
                        this.github = github;
                    }

                    public static class GithubBean {
                        /**
                         * username : dyc87112
                         * avatarLarge : https://avatars0.githubusercontent.com/u/3391170?v=4
                         * uid : 3391170
                         */

                        private String username;
                        private String avatarLarge;
                        private String uid;

                        public String getUsername() {
                            return username;
                        }

                        public void setUsername(String username) {
                            this.username = username;
                        }

                        public String getAvatarLarge() {
                            return avatarLarge;
                        }

                        public void setAvatarLarge(String avatarLarge) {
                            this.avatarLarge = avatarLarge;
                        }

                        public String getUid() {
                            return uid;
                        }

                        public void setUid(String uid) {
                            this.uid = uid;
                        }
                    }
                }
            }

            public static class CategoryBean {
                /**
                 * ngxCached : true
                 * title : backend
                 * id : 5562b419e4b00c57d9b94ae2
                 * name : 后端
                 * ngxCachedTime : 1553826952
                 */

                private boolean ngxCached;
                private String title;
                private String id;
                private String name;
                private int ngxCachedTime;

                public boolean isNgxCached() {
                    return ngxCached;
                }

                public void setNgxCached(boolean ngxCached) {
                    this.ngxCached = ngxCached;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getId() {
                    return id;
                }

                public void setId(String id) {
                    this.id = id;
                }

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }

                public int getNgxCachedTime() {
                    return ngxCachedTime;
                }

                public void setNgxCachedTime(int ngxCachedTime) {
                    this.ngxCachedTime = ngxCachedTime;
                }
            }

            public static class TagsBean {
                /**
                 * ngxCachedTime : 1553826996
                 * ngxCached : true
                 * title : 后端
                 * id : 5597a063e4b08a686ce57030
                 */

                private int ngxCachedTime;
                private boolean ngxCached;
                private String title;
                private String id;

                public int getNgxCachedTime() {
                    return ngxCachedTime;
                }

                public void setNgxCachedTime(int ngxCachedTime) {
                    this.ngxCachedTime = ngxCachedTime;
                }

                public boolean isNgxCached() {
                    return ngxCached;
                }

                public void setNgxCached(boolean ngxCached) {
                    this.ngxCached = ngxCached;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getId() {
                    return id;
                }

                public void setId(String id) {
                    this.id = id;
                }
            }
        }
    }
}
